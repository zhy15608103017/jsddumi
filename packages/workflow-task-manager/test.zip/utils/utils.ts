/* eslint-disable @typescript-eslint/explicit-function-return-type */
export function serializeSortParams(params: any, sortPriority?: string[]) {
    const addPrefixFields = ['createdTime', 'lastModifiedTime'];
    if (!params) return params;
    let result: string[];
    if (sortPriority && sortPriority.length > 0) {
        result = [];
        sortPriority.forEach((dataIndex) => {
            if (params[dataIndex]) {
                const sort = params[dataIndex] === 'ascend' ? 'asc' : 'desc';
                const dealedSort = addPrefixFields.includes(dataIndex)
                    ? `audit.${dataIndex},${sort}`
                    : `${dataIndex},${sort}`;
                result.push(dealedSort);
            }
        });
        return result;
    }
    result = Object.keys(params).map((key) => {
        const sort = params[key] === 'ascend' ? 'asc' : 'desc';
        return addPrefixFields.includes(key) ? `audit.${key},${sort}` : `${key},${sort}`;
    });
    return result;
}