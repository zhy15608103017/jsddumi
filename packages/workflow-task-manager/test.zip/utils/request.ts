import { extend } from '@jusda-test/web-api-client';
// @ts-ignore
import { mpApiUrl } from '@jusda-tools/url-config';
// import { envBaseUrl } from "@jusda-tools/component-base-config-tools";

const request: any = extend({});

request.interceptors.request.use(
  (url, options) => {
    // @ts-ignore
    const { headers } = options;
    return {
      url: mpApiUrl +  url,
      options: {
        ...options,
        headers: {
          ...headers,
        },
      },
    };
  },
  { global: false }
);

export default request;