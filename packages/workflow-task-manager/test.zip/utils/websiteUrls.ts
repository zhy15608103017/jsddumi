/* eslint-disable @typescript-eslint/no-explicit-any */
// @ts-ignore
import { mp_ac_url, mp_ch_url } from '@jusda-tools/url-config';

export const websitePaths: any = {
    // 公告中心
    ac: {
        dev: 'https://mpdev.jus-link.com/ac/',
        sit: 'https://mpsit.jus-link.com/ac/',
        uat: 'https://mpuat.jus-link.com/ac/',
        prod: 'https://mp.jus-link.com/ac/',
    },
    // 帮助中心
    ch: {
        dev: 'https://mpdev.jus-link.com/ch/',
        sit: 'https://mpsit.jus-link.com/ch/',
        uat: 'https://mpuat.jus-link.com/ch/',
        prod: 'https://mp.jus-link.com/ch/',
    },
};

export const websitePathsBackup: any = {
    ac: mp_ac_url,
    ch: mp_ch_url
}