/// <reference types="react" />
declare const flod: JSX.Element;
declare const applyIncon: JSX.Element;
declare const shipment_demand_app: JSX.Element;
declare const Visual_transport_query: JSX.Element;
declare const visual_inventory_vendor: JSX.Element;
declare const Visual_report: JSX.Element;
declare const customer_reconciliation: JSX.Element;
declare const commercial_order_portal: JSX.Element;
declare const commercial_order_process: JSX.Element;
declare const evmi_new_portal: JSX.Element;
declare const arrow_down: JSX.Element;
declare const arrow_right: JSX.Element;
export { flod, applyIncon, shipment_demand_app, Visual_transport_query, visual_inventory_vendor, Visual_report, customer_reconciliation, commercial_order_portal, commercial_order_process, evmi_new_portal, arrow_down, arrow_right, };
