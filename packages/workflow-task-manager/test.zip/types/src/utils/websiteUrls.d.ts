export declare const websitePaths: any;
export declare const websitePathsBackup: any;
