declare const request: any;
export default request;
