import React from 'react';
import './applydrawerLight.less';
import './applydrawerDark.less';
interface ApplyDrawerProps {
    visible: boolean;
    showState: any;
    onChangeVisible: Function;
    onChangeShowState: Function;
    language: 'zh-CN' | 'en-US';
    theme?: 'light' | 'dark';
    navigationData: any;
}
declare const ApplyDrawer: React.FC<ApplyDrawerProps>;
export default ApplyDrawer;
