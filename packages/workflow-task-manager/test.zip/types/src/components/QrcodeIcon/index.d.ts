import React from 'react';
import './styles/dark.less';
import './styles/light.less';
interface ScanQrcodeIconProps {
    theme?: 'light' | 'dark';
    locale?: 'zh-CN' | 'en-US';
}
declare const ScanQrcodeIcon: React.FC<ScanQrcodeIconProps>;
export default ScanQrcodeIcon;
