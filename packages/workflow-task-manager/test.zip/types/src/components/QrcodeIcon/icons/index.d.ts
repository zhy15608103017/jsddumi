export declare const qrcodeIcon: any;
