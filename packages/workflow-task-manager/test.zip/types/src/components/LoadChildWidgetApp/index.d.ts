import React from "react";
interface LoadChildWidgetAppProps {
    name?: string;
    entry?: string;
    id?: string;
    type?: string;
    returnPath?: string;
}
export declare const LoadChildWidgetApp: (props: LoadChildWidgetAppProps) => React.ReactElement;
export {};
