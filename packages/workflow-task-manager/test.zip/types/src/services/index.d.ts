export declare function fetchTodo(): Promise<{
    success: boolean;
    data: {
        content: {
            name: string;
            code: string;
            url: string;
            description: string;
        }[];
        totalElements: number;
    };
}>;
export declare function fetchDone(): Promise<{
    success: boolean;
    data: {
        content: {
            name: string;
            code: string;
            url: string;
            description: string;
        }[];
        totalElements: number;
    };
}>;
