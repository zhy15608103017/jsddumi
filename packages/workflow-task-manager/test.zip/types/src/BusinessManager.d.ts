import React from "react";
declare type BusinessManagerProps = {
    type?: "whole" | "part";
};
export default function BusinessManager(props: BusinessManagerProps): React.ReactElement;
export {};
