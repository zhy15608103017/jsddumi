export declare const helpIcon: any;
export declare const announcementIcon: any;
