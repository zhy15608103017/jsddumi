export declare function genTodoColumns(props: any): any[];
export declare function genDoneColumns(props: any): any[];
