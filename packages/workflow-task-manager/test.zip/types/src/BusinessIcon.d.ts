import React from "react";
import './BusinessIcon.less';
interface BusinessIconProps {
    theme?: 'light' | 'dark';
}
declare function BusinessIcon(props: BusinessIconProps): React.ReactElement;
export default BusinessIcon;
