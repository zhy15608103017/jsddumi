import React from 'react';
import './styles/dark.less';
import './styles/light.less';
interface OpenTargetTabConfigType {
    helpCenter?: boolean;
    announcementCenter?: boolean;
    personalCenter?: boolean;
    messagesCenter?: boolean;
}
interface UserIdentitySwitcherType {
    enable?: boolean;
    requirePermission?: boolean;
    subMenuWrapClassName?: string;
}
interface HeaderProps {
    locale?: any;
    theme?: 'light' | 'dark';
    showNavigation?: boolean;
    onLogout?: () => void;
    onIdentityChange?: () => void;
    logoReplaceReactNode?: React.ReactNode;
    leftReactNode?: React.ReactNode;
    rightReactNode?: React.ReactNode;
    userIdentitySwitcher?: UserIdentitySwitcherType;
    openTargetTabConfig?: OpenTargetTabConfigType;
}
declare const Header: React.FC<HeaderProps>;
export default Header;
