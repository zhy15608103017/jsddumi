declare type Loading = boolean;
declare type Run = (...args: any[]) => Promise<any>;
declare function useRequest(requestFn: any): [Loading, Run];
export default useRequest;
