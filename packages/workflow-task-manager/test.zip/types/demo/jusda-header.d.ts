import * as React from 'react';
declare const AppLayout: React.FC;
export default AppLayout;
