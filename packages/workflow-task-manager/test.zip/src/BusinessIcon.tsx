import React, { useState } from "react";
import TodoIcon from "./assets/icon/todo.svg";
import BusinessManager from "./BusinessManager";
import './BusinessIcon.less';

interface BusinessIconProps  {
    theme?: 'light'|   'dark';
}

function BusinessIcon(props: BusinessIconProps): React.ReactElement {
    const { theme = 'light', } = props;
    const [showDetail, setShowDetail] = useState(false);
    function handleClick(): void {
        setShowDetail(!showDetail);
    }
    return (
		<div className={`iconBox-${theme === 'dark'?theme:'light'}`}>
			<span  className="icon" onClick={handleClick}><TodoIcon/></span>
			<div style={{display:showDetail?'block':'none'}} className='managerBox'>
			    <BusinessManager/>
			</div>
		</div>
    );
}

export default BusinessIcon;
