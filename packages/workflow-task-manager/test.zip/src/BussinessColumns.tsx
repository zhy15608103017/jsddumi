import dayjs from "dayjs";
import GotoIcon from "./assets/icon/goto.svg";
import CheckIcon from "./assets/icon/check.svg";
import React from "react";
import { Button, Tooltip } from "antd";

const baseColumns = [
    {
        title: "事项",
        dataIndex: "name",
        key: "name",
        ellipsis: true,
    },
    {
        title: "业务域",
        dataIndex: "code",
        key: "code",
        ellipsis: true,
    },
    {
        title: "业务场景",
        dataIndex: "application",
        key: "application",
        ellipsis: true,
    },
    {
        title: "时间",
        dataIndex: "lastModifiedTime",
        key: "lastModifiedTime",
        render(lastModifiedTime: string) {
            return lastModifiedTime
                ? dayjs(lastModifiedTime).format("YYYY-MM-DD HH:mm:ss")
                : "-";
        },
        ellipsis: true,
    },
];

export function genTodoColumns(props): any[] {
    return [
        ...baseColumns,
        {
            title: "操作",
            align: "center",
            width: 80,
            render(_: any, item: any) {
                return (
                    <Tooltip title={"编辑"}>
                        <Button
                            type="link"
                            icon={ <span className="operate_icon"><GotoIcon/></span>}
                            onClick={() => {
                                props?.editDetail(item);
                            }}
                        />
                    </Tooltip>
                );
            },
        },
    ];
}

export function genDoneColumns(props): any[] {
    return [
        ...baseColumns,
        {
            title: "操作",
            align: "center",
            width: 80,
            // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
            render(_: any, item: any) {
                return (
                    <Tooltip title={"查看"}>
                        <Button
                            type="link"
                            icon={<span className="operate_icon"><CheckIcon/></span>}
                            onClick={() => {
                                props?.showDetail(item);
                            }}
                        />
                    </Tooltip>
                );
            },
        },
    ];
}
