/* eslint-disable @typescript-eslint/explicit-function-return-type */
import { Button, Input, Modal, Space, Table, Tabs } from "antd";
import React, { useEffect, useState } from "react";
import { genDoneColumns, genTodoColumns } from "./BussinessColumns";
import { LoadChildWidgetApp } from "./components/LoadChildWidgetApp";
import useRequest from "./hooks/useRequest";
import { fetchDone, fetchTodo } from "./services";

type BusinessManagerProps = {
    type?: "whole" | "part";
};

type TableData = {
    content: any[];
    totalElements: number;
};

export default function BusinessManager(
    props: BusinessManagerProps
): React.ReactElement {
    const { type = "whole" } = props;
    const [todoData, setTododata] = useState<TableData | undefined>();
    const [doneData, setDoneData] = useState<TableData | undefined>();
    const [todoLoading, runFetchToto] = useRequest(fetchTodo);
    const [doneLoading, runFetchDone] = useRequest(fetchDone);
    const [data4Show, setData4Show] = useState<{
        name: string;
        entry: string;
        id: string;
        isEditable?: boolean;
        decription?: string;
    } | null>(null);

    const showDetail = (item: any) => {
        const { name, code, url, ...rest } = item;
        setData4Show({
            name,
            id: code,
            entry: url,
            isEditable: false,
            ...rest,
        });
    };
    const editDetail = (item: any) => {
        const { name, code, url, ...rest } = item;
        setData4Show({ name, id: code, entry: url, isEditable: true, ...rest });
    };

    const handler = {
        showDetail,
        editDetail,
    };

    const handleCancel = () => {
        setData4Show(null);
    };

    async function initData(
        fetchFunc: (params?: any) => Promise<any>,
        setData: (data: any) => void
    ): Promise<void> {
        const resp = await fetchFunc();
        const { success, data } = resp || {};
        if (!success) return;
        setData(data);
    }

    // eslint-disable-next-line @typescript-eslint/explicit-function-return-type
    useEffect(() => {
        initData(runFetchToto, setTododata);
        initData(runFetchDone, setDoneData);
    }, []);
    return (
        <>
            <Tabs>
                <Tabs.TabPane
                    tab={
                        <div>
                            待审批
                            <span>
                                (
                                {typeof todoData?.totalElements === "number"
                                    ? todoData?.totalElements
                                    : "-"}
                                )
                            </span>
                        </div>
                    }
                    key="1"
                >
                    <Table
                        pagination={false}
                        className="businessTable"
                        columns={genTodoColumns(handler)}
                        loading={todoLoading}
                        dataSource={todoData?.content}
                        footer={() => (
                            <div className="businessTable_footer">
                                <Button className="footer_btn">查看更多</Button>
                            </div>
                        )}
                    />
                </Tabs.TabPane>
                <Tabs.TabPane
                    tab={
                        <div>
                            已完成
                            <span>
                                (
                                {typeof doneData?.totalElements === "number"
                                    ? doneData?.totalElements
                                    : "-"}
                                )
                            </span>
                        </div>
                    }
                    key="2"
                >
                    <Table
                        pagination={false}
                        className="businessTable"
                        columns={genDoneColumns(handler)}
                        loading={doneLoading}
                        dataSource={doneData?.content}
                        footer={() => (
                            <div className="businessTable_footer">
                                <Button className="footer_btn">查看更多</Button>
                            </div>
                        )}
                    />
                </Tabs.TabPane>
            </Tabs>
            <Modal
                visible={!!data4Show}
                onCancel={handleCancel}
                title="代办处理"
                footer={
                    <div>
                        {data4Show?.isEditable ? (
                            <Space>
                                <Button>驳回</Button>
                                <Button type="primary">通过</Button>
                            </Space>
                        ) : (
                            <Button onClick={handleCancel}>取消</Button>
                        )}
                    </div>
                }
            >
                <LoadChildWidgetApp {...(data4Show || {})} />
                <Input.TextArea
                    disabled={data4Show?.isEditable}
                    value={data4Show?.decription}
                />
            </Modal>
        </>
    );
}
