export async function fetchTodo() {
	return Promise.resolve({
		success: true,
		data: {
			content: [
				{
					name: "test",
					code: "test",
					url: "http://10.253.12.45:8003/",
                    description: "test",
				},
			],
			totalElements: 1,
		},
	});
}

export async function fetchDone() {
	return Promise.resolve({
		success: true,
		data: {
			content: [
				{
					name: "test2",
					code: "test2",
					url: "http://10.253.12.45:8003/",
                    description: "test2",
				},
			],
			totalElements: 1,
		},
	});
}
