import BusinessIcon from "./BusinessIcon";
import BusinessManager from "./BusinessManager";

export { BusinessManager };
export default BusinessIcon;
