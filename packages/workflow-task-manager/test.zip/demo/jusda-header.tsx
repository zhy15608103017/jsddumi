import * as React from 'react';
// @ts-ignore
import Header from '../dist/index.js';

const AppLayout: React.FC = (props) => {

    return (
        <div>
            <div>
                <Header theme="light" locale="en-US" />
            </div>
        </div>
    );
};

export default AppLayout;
